package org.com.capg.healthcare.dao;

import java.util.List;

import org.com.capg.healthcare.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;



public interface AppointmentRepository extends JpaRepository<Appointment, String>
{

	
	

}
