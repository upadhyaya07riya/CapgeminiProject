package org.com.capg.healthcare.exception;

public class ScheduledException extends Exception {

	public ScheduledException() {
		super();
	
	}

	public ScheduledException(String message) {
		super(message);

	}

}
