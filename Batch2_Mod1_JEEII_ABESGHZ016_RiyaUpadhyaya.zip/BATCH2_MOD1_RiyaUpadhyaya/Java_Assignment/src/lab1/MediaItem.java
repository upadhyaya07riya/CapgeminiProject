package lab1;


public abstract class MediaItem extends Item {

	private int runtime;
}

