export interface Wallet {
    accountId : number,
    balance : number,
    account : Account
}
