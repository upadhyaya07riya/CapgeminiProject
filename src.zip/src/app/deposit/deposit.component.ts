
import { Component } from "@angular/core";
import { wallet } from "./models/wallet";


@Component({
    selector:'deposit',
    templateUrl:'deposit.html'
})



export class DepositAccountComponent{
    constructor(private service:walletService){}
    model:wallet=
    {
        id:0,
        amount:0
    }
    deposit()
    {
        this.service.deposit(this.model).subscribe(
            res=>console.log(res)
        )
      alert("Amount Deposit Successful !");
    }
}