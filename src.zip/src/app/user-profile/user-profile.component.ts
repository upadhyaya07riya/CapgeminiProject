export class SearchEmployeeComponent{
  acc:Account
  constructor(private service:walletService){}
  id:number;
  ch=false;
  change()
  {
      this.ch=true;
  }
  finddata()
  {
    console.log(this.id)
      this.service.findemployee(this.id).subscribe(
          res=>{
              this.acc=res
          },
          err=>{
              alert("an error has occurred")
          }
      )     
  }
}