package main;

import dao.AuthorDao;

public class AuthorMain {

	public static void main(String[] args) {
		AuthorDao authorDao=new AuthorDao();
		
		//Create/add new Author
		/*
		Author author=new Author("shiv","malhotra","923851047435");
		String result=authorDao.addAuthor(author);
		System.out.println(result);
		*/
		
		//Find Author by given Author ID
		/*
		Author author=authorDao.getAuthorById(46);
	    System.out.println(author.getFirstName()+"\t"+author.getLastName()+"\t"+author.getPhoneNo());
	    */
		
		//Update details of an author
		/*
		Author author=new Author("anuj", "malhotra", "98263643648");
		String result1=authorDao.updateAuthorById(47, author);
	    System.out.println(result1);
	    */
		
		// Delete author by Author ID
		
		String result3=authorDao.removeAuthorById(65);
		System.out.println(result3);
	}
	
}
